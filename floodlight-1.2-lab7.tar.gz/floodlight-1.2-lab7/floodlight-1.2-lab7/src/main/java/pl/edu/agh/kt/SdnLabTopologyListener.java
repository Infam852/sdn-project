package pl.edu.agh.kt;
import java.util.ArrayList;
import java.util.List;

import org.projectfloodlight.openflow.types.DatapathId;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import net.floodlightcontroller.core.IFloodlightProviderService;
import net.floodlightcontroller.core.IOFSwitch;

import net.floodlightcontroller.core.internal.IOFSwitchService;
import net.floodlightcontroller.core.internal.OFSwitchManager;
import net.floodlightcontroller.core.module.FloodlightModuleContext;
import net.floodlightcontroller.linkdiscovery.ILinkDiscovery;
import net.floodlightcontroller.linkdiscovery.ILinkDiscovery.LDUpdate;
import net.floodlightcontroller.topology.ITopologyListener;

public class SdnLabTopologyListener implements ITopologyListener {
	
	protected static final Logger logger = LoggerFactory.getLogger(SdnLabTopologyListener.class);
	private List<StatisticsCollector> listenerList = new ArrayList<>();
	private StatisticsCollector labListener;
	protected IOFSwitchService switchService;
	
	protected IFloodlightProviderService floodlightProvider;
	
	@Override
	public void topologyChanged(List<LDUpdate> linkUpdates) {
		logger.debug("Received topology status");
		for (ILinkDiscovery.LDUpdate update : linkUpdates) {
			DatapathId switchDPID;
			switch (update.getOperation()) {
			case SWITCH_UPDATED:
				logger.debug("Switch updated. Update {}", update.toString());
				switchDPID = update.getSrc();
				logger.info("Switch ID: {}", switchDPID);
				IOFSwitch sw = switchService.getSwitch(switchDPID);
				labListener = new StatisticsCollector(sw);
				listenerList.add(labListener);
				break;
			}
		}
	}
}