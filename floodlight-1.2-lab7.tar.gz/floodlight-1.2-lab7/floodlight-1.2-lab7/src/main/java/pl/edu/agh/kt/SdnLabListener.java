package pl.edu.agh.kt;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.projectfloodlight.openflow.protocol.OFMessage;
import org.projectfloodlight.openflow.protocol.OFPacketIn;
import org.projectfloodlight.openflow.protocol.OFType;
import org.projectfloodlight.openflow.types.OFPort;

import net.floodlightcontroller.core.FloodlightContext;
import net.floodlightcontroller.core.IOFMessageListener;
import net.floodlightcontroller.core.IOFSwitch;
import net.floodlightcontroller.core.module.FloodlightModuleContext;
import net.floodlightcontroller.core.module.FloodlightModuleException;
import net.floodlightcontroller.core.module.IFloodlightModule;
import net.floodlightcontroller.core.module.IFloodlightService;

import net.floodlightcontroller.core.IFloodlightProviderService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SdnLabListener implements IFloodlightModule, IOFMessageListener {

	protected IFloodlightProviderService floodlightProvider;
	protected static Logger logger;

	@Override
	public String getName() {
		return SdnLabListener.class.getSimpleName();
	}

	@Override
	public boolean isCallbackOrderingPrereq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isCallbackOrderingPostreq(OFType type, String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public net.floodlightcontroller.core.IListener.Command receive(IOFSwitch sw, OFMessage msg,
			FloodlightContext cntx) {

		logger.info("************* NEW PACKET IN *************");
//		PacketExtractor extractor = new PacketExtractor();
//		extractor.packetExtract(cntx);

		// TODO LAB 6
		OFPacketIn pin = (OFPacketIn) msg;
		OFPort outPort = OFPort.of(0);
		if (pin.getInPort() == OFPort.of(1)) {
			outPort = OFPort.of(2);
		} else
			outPort = OFPort.of(1);
		Flows.simpleAdd(sw, pin, cntx, outPort);

		/*  Test tworzenie topologii */
		NetworkTopology networkTopology = NetworkTopology.getInstance();
		logger.info("H0ToH1 SourceHost: {}", networkTopology.getDemands().get(0).getSourceHost());
		logger.info("H2ToH0 is second link on third path congested: {}", networkTopology.getDemands().get(3).getPaths().get(2).getLinks().get(1).getIsCongested());
		logger.info("H2ToH0 third path congested: {}", networkTopology.getDemands().get(3).getPaths().get(2).getisCongested());
		networkTopology.getDemands().get(3).getPaths().get(2).getLinks().get(2).setIsCongested(true);
		logger.info("H2ToH0 is the third link on the third path congested: {}", networkTopology.getDemands().get(3).getPaths().get(2).getLinks().get(2).getIsCongested());
		logger.info("H2ToH0 third path congested: {}", networkTopology.getDemands().get(3).getPaths().get(2).getisCongested());
		logger.info("H1ToH2 DdestinationHost: {}", networkTopology.getDemands().get(4).getDestinationHost());
		logger.info("H2ToH1 First node of second link of third path: {}", networkTopology.getDemands().get(5).getPaths().get(2).getLinks().get(1).getFirstNode());
		logger.info("H0ToH2 is the second link on the first path congested: {}", networkTopology.getDemands().get(2).getPaths().get(0).getLinks().get(1).getIsCongested());
		logger.info("H0ToH2 is the second link on the third path congested: {}", networkTopology.getDemands().get(2).getPaths().get(2).getLinks().get(1).getIsCongested());
		logger.info("H0ToH1 is the second link on the first path congested: {}", networkTopology.getDemands().get(0).getPaths().get(0).getLinks().get(1).getIsCongested());
		logger.info("H0ToH1 is the second link on the third path congested: {}", networkTopology.getDemands().get(0).getPaths().get(2).getLinks().get(1).getIsCongested());
		logger.info("H0ToH1 is the third path congested: {}", networkTopology.getDemands().get(0).getPaths().get(2).getisCongested());
		logger.info("H0ToH2 congestion at the second link on the first path set to true");
		networkTopology.getDemands().get(2).getPaths().get(0).getLinks().get(1).setIsCongested(true);
		logger.info("H0ToH2 is the second link on the first path congested: {}", networkTopology.getDemands().get(2).getPaths().get(0).getLinks().get(1).getIsCongested());
		logger.info("H0ToH2 is the second link on the third path congested: {}", networkTopology.getDemands().get(2).getPaths().get(2).getLinks().get(1).getIsCongested());
		logger.info("H0ToH1 is the second link on the first path congested: {}", networkTopology.getDemands().get(0).getPaths().get(0).getLinks().get(1).getIsCongested());
		logger.info("H0ToH1 is the second link on the third path congested: {}", networkTopology.getDemands().get(0).getPaths().get(2).getLinks().get(1).getIsCongested());
		logger.info("H0ToH1 is the third path congested: {}", networkTopology.getDemands().get(0).getPaths().get(2).getisCongested());
		return Command.STOP;
	}

	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleServices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<Class<? extends IFloodlightService>, IFloodlightService> getServiceImpls() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Class<? extends IFloodlightService>> getModuleDependencies() {
		Collection<Class<? extends IFloodlightService>> l = new ArrayList<Class<? extends IFloodlightService>>();
		l.add(IFloodlightProviderService.class);
		return l;
	}

	@Override
	public void init(FloodlightModuleContext context) throws FloodlightModuleException {
		floodlightProvider = context.getServiceImpl(IFloodlightProviderService.class);
		logger = LoggerFactory.getLogger(SdnLabListener.class);
	}

	@Override
	public void startUp(FloodlightModuleContext context) throws FloodlightModuleException {
		floodlightProvider.addOFMessageListener(OFType.PACKET_IN, this);
		logger.info("******************* START **************************");

	}

}
