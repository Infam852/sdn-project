package pl.edu.agh.kt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.projectfloodlight.openflow.protocol.OFFlowStatsEntry;
import org.projectfloodlight.openflow.protocol.OFFlowStatsReply;
import org.projectfloodlight.openflow.protocol.OFPortStatsEntry;
import org.projectfloodlight.openflow.protocol.OFPortStatsReply;
import org.projectfloodlight.openflow.protocol.OFStatsReply;
import org.projectfloodlight.openflow.protocol.OFStatsRequest;
import org.projectfloodlight.openflow.protocol.match.MatchField;
import org.projectfloodlight.openflow.protocol.match.Match;
import org.projectfloodlight.openflow.types.OFPort;
import org.projectfloodlight.openflow.types.TableId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.common.util.concurrent.ListenableFuture;
import net.floodlightcontroller.core.IOFSwitch;


public class StatisticsCollector {
	private static final Logger logger = LoggerFactory.getLogger(StatisticsCollector.class);
	private IOFSwitch sw;
	
	public class PortStatisticsPoller extends TimerTask {
		private final Logger logger = LoggerFactory.getLogger(PortStatisticsPoller.class);
		
		@Override
		public void run() {
			logger.info("run() begin");
			Map<String, Object> flow_data;
			List<Map<String, Object>> flow_list = new ArrayList<Map<String, Object>>();
			synchronized (StatisticsCollector.this) {
				if (sw == null) { // no switch
					logger.error("run() end (no switch)");
					return;}
				
				ListenableFuture<?> future_flow;
				List<OFStatsReply> flow_values = null;
				OFStatsRequest<?> flow_req = null;
				flow_req = sw.getOFFactory().buildFlowStatsRequest().setOutPort(OFPort.ANY).setTableId(TableId.ALL).build();

				try {
					if (flow_req != null) {
						future_flow = sw.writeStatsRequest(flow_req);
						flow_values = (List<OFStatsReply>) future_flow.get(PORT_STATISTICS_POLLING_INTERVAL * 1000 / 2, TimeUnit.MILLISECONDS);
					}
					OFFlowStatsReply fsr = (OFFlowStatsReply) flow_values.get(0);
					
					logger.info("Switch id: {}", sw.getId());

					for (OFFlowStatsEntry fse : fsr.getEntries()) {
						
						Match m = fse.getMatch();
						
						flow_data = new HashMap<String, Object>();
						flow_data.put("In port", fse.getMatch().get(MatchField.IN_PORT).getPortNumber());
						flow_data.put("Eth src", fse.getMatch().get(MatchField.ETH_SRC).toString());
						flow_data.put("Eth dst", fse.getMatch().get(MatchField.ETH_DST).toString());
						flow_data.put("Eth type", fse.getMatch().get(MatchField.ETH_TYPE).getValue());
						flow_data.put("Ip proto", fse.getMatch().get(MatchField.IP_PROTO).getIpProtocolNumber());
						flow_data.put("Tcp src", fse.getMatch().get(MatchField.TCP_SRC).getPort());
						flow_data.put("Tcp dst", fse.getMatch().get(MatchField.TCP_DST).getPort());
						flow_data.put("Ipv4 src", fse.getMatch().get(MatchField.IPV4_SRC).toString());
						flow_data.put("Ipv4 dst", fse.getMatch().get(MatchField.IPV4_DST).toString());
						flow_data.put("Flow duration",fse.getDurationSec());
						flow_data.put("Bytes number", fse.getByteCount().getValue());
						flow_data.put("Priority", fse.getPriority());
						
						logger.info("{}", flow_data.get("In port"));
						logger.info("{}", flow_data.get("Eth src"));
						logger.info("{}", flow_data.get("Eth dst"));
						logger.info("{}", flow_data.get("Eth type"));
						logger.info("{}", flow_data.get("Ip proto"));
						logger.info("{}", flow_data.get("Tcp src"));
						logger.info("{}", flow_data.get("Tcp dst"));
						logger.info("{}", flow_data.get("Ipv4 src"));
						logger.info("{}", flow_data.get("Ipv4 dst"));
						logger.info("{}", flow_data.get("Flow duration"));
						logger.info("{}", flow_data.get("Bytes number"));
						logger.info("{}", flow_data.get("Priority"));
						
						if (to jest elephant){
							Flows.simpleAdd2(sw, pin, cntx, outPort, m);
						}
						
						flow_list.add(flow_data);
						
					}
				} catch (InterruptedException | ExecutionException | TimeoutException ex) {
						logger.error("Error during statistics polling", ex);
				}
			}
			logger.debug("run() end");
			return;
		}
	}
	
	
	public static final int PORT_STATISTICS_POLLING_INTERVAL = 3000; // in ms
//	private static StatisticsCollector singleton;
	public StatisticsCollector(IOFSwitch sw) {
		this.sw = sw;
		new Timer().scheduleAtFixedRate(new PortStatisticsPoller(), 0, PORT_STATISTICS_POLLING_INTERVAL);
	}
	
//	public static StatisticsCollector getInstance(IOFSwitch sw) {
//		logger.debug("getInstance() begin");
//		synchronized (StatisticsCollector.class) {
//			if (singleton == null) {
//				logger.debug("Creating StatisticsCollector singleton");
//				singleton = new StatisticsCollector(sw);
//			}
//		}
//		logger.debug("getInstance() end");
//		return singleton;
//	}

}
