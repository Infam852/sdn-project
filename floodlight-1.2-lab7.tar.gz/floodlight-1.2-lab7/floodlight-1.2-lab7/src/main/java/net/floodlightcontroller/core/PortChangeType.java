package net.floodlightcontroller.core;

/**
 * the type of change that happened to an open flow port
 */
public enum PortChangeType {
    ADD, OTHER_UPDATE, DELETE, UP, DOWN,
}