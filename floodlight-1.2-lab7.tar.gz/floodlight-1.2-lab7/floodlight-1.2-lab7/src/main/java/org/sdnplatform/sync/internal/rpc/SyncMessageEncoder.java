package org.sdnplatform.sync.internal.rpc;

import org.sdnplatform.sync.thrift.SyncMessage;

import net.floodlightcontroller.core.util.ThriftFrameEncoder;

public class SyncMessageEncoder extends ThriftFrameEncoder<SyncMessage> {

}